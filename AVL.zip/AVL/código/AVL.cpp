#include <iostream>
using namespace std;

// Defini��o da estrutura do n� da �rvore AVL
struct Node {
    int key;
    Node* left;
    Node* right;
    int height;
};

// Fun��o para criar um novo n� com a chave dada
Node* newNode(int key) {
    Node* node = new Node;
    node->key = key;
    node->left = nullptr;
    node->right = nullptr;
    node->height = 1; // Inicializa a altura como 1 (novo n� � uma folha)
    return node;
}

// Fun��o para calcular a altura de um n�
int getHeight(Node* node) {
    if (node == nullptr) return 0;
    return node->height;
}

// Fun��o para atualizar a altura de um n� com base nas alturas de suas sub�rvores
void updateHeight(Node* node) {
    node->height = 1 + max(getHeight(node->left), getHeight(node->right));
}

// Fun��o para calcular o fator de balanceamento de um n�
int getBalanceFactor(Node* node) {
    if (node == nullptr) return 0;
    return getHeight(node->left) - getHeight(node->right);
}

// Rota��o � esquerda simples (LL)
Node* leftRotate(Node* y) {
    Node* x = y->right;
    Node* T2 = x->left;
    x->left = y;
    y->right = T2;
    updateHeight(y);
    updateHeight(x);
    return x;
}

// Rota��o � direita simples (RR)
Node* rightRotate(Node* x) {
    Node* y = x->left;
    Node* T2 = y->right;
    y->right = x;
    x->left = T2;
    updateHeight(x);
    updateHeight(y);
    return y;
}

// Inser��o de um n� na �rvore AVL
Node* insert(Node* root, int key) {
    if (root == nullptr) return newNode(key);

    if (key < root->key)
        root->left = insert(root->left, key);
    else if (key > root->key)
        root->right = insert(root->right, key);
    else // Ignorar chaves duplicadas
        return root;

    updateHeight(root);

    int balance = getBalanceFactor(root);

    // Casos de desequil�brio
    if (balance > 1) {
        if (key < root->left->key) // Inser��o � esquerda do filho esquerdo (LL)
            return rightRotate(root);
        else { // Inser��o � direita do filho esquerdo (LR)
            root->left = leftRotate(root->left);
            return rightRotate(root);
        }
    }

    if (balance < -1) {
        if (key > root->right->key) // Inser��o � direita do filho direito (RR)
            return leftRotate(root);
        else { // Inser��o � esquerda do filho direito (RL)
            root->right = rightRotate(root->right);
            return leftRotate(root);
        }
    }

    return root;
}

// Fun��o para percorrer a �rvore em ordem
void inorderTraversal(Node* root) {
    if (root != nullptr) {
        inorderTraversal(root->left);
        cout << root->key << " ";
        inorderTraversal(root->right);
    }
}

int main() {
    Node* root = nullptr;

    root = insert(root, 10);
    root = insert(root, 20);
    root = insert(root, 30);
    root = insert(root, 40);
    root = insert(root, 50);
    root = insert(root, 25); // Inserindo 25 para causar desequil�brio

    cout << "�rvore AVL em ordem: ";
    inorderTraversal(root);

    return 0;
}
